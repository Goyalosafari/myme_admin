<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class CategoryResource extends JsonResource
{
    public function toArray($request)
    {
        return [
            'id'    => $this->id,
            'title' => $this->title,
            'image'            => 'storage/app/public/' . $this->image,
            'type'  => $this->type,
            'ref'   => $this->ref,
        ];
    }
}
