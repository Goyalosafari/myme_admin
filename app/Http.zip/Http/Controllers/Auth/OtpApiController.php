<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Wallet;
use App\Services\SmsService;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Mail;

class OtpApiController extends Controller
{
    protected $sms;

    public function __construct(SmsService $sms)
    {
        $this->sms = $sms;
    }

    // Called by Flutter register screen: sends email OTP for new user verification
    public function sendOtp(Request $request)
    {
        // Email-based OTP (registration flow)
        if ($request->filled('email')) {
            $request->validate([
                'email' => 'required|email',
                'otp'   => 'required|digits:4',
            ]);

            if (User::where('email', $request->email)->exists()) {
                return response(['message' => 'Email already registered. Please login.'], 409);
            }

            try {
                Mail::raw(
                    "Your MYME registration OTP is: {$request->otp}\n\nValid for 20 minutes.",
                    function ($msg) use ($request) {
                        $msg->to($request->email)
                            ->subject('MYME – Email Verification OTP');
                    }
                );
            } catch (\Exception $e) {
                // If mail is not configured, still return 200 so the OTP dialog shows
                // Remove this catch block once mail is configured in .env
            }

            return response(['message' => 'OTP sent successfully'], 200);
        }

        // Mobile/SMS-based OTP (phone verification flow)
        $request->validate([
            'mobile' => 'required|digits:10',
        ]);

        $user = User::where('mobile', $request->mobile)->first();
        if (!$user) {
            return response(['message' => 'Mobile number not registered'], 404);
        }

        $otp     = rand(100000, 999999);
        $expires = Carbon::now()->addMinutes(10);

        $user->update([
            'otp'            => (string) $otp,
            'otp_expires_at' => $expires,
        ]);

        $message    = "Your MYME verification OTP is {$otp}. Valid for 10 minutes.";
        $templateId = '1707173462931959706';

        try {
            $this->sms->sendSms($request->mobile, $message, $templateId);
        } catch (\Exception $e) {
            // SMS failed — still return OTP so local testing works
        }

        return response(['message' => 'OTP sent successfully', 'otp' => (string) $otp], 200);
    }

    // Registration / profile-mobile-update OTP — no existing user required
    public function sendRegisterOtp(Request $request)
    {
        $request->validate(['mobile' => 'required|digits:10']);

        $otp        = (string) rand(100000, 999999);
        $message    = "Your MYME OTP is {$otp}. Valid for 10 minutes.";
        $templateId = '1707173462931959706';

        Cache::put('reg_otp_' . $request->mobile, $otp, 600);

        try {
            $this->sms->sendSms($request->mobile, $message, $templateId);
        } catch (\Exception $e) {
            // SMS failed but still return OTP for local testing
        }

        return response(['message' => 'OTP sent successfully', 'otp' => $otp], 200);
    }

    public function verifyRegisterOtp(Request $request)
    {
        $request->validate([
            'mobile' => 'required|digits:10',
            'otp'    => 'required|digits:6',
        ]);

        $cached = Cache::get('reg_otp_' . $request->mobile);

        if (!$cached || $cached !== $request->otp) {
            return response(['message' => 'Invalid OTP'], 422);
        }

        Cache::forget('reg_otp_' . $request->mobile);
        return response(['message' => 'OTP verified successfully'], 200);
    }

    // Called for mobile OTP verification
    public function verifyOtp(Request $request)
    {
        $request->validate([
            'mobile' => 'required|digits:10',
            'otp'    => 'required|digits:6',
        ]);

        $user = User::where('mobile', $request->mobile)->first();
        if (!$user) {
            return response(['message' => 'Mobile number not found'], 404);
        }

        if ($user->otp !== $request->otp) {
            return response(['message' => 'Invalid OTP'], 422);
        }

        if (Carbon::now()->gt($user->otp_expires_at)) {
            return response(['message' => 'OTP expired'], 422);
        }

        $user->update([
            'otp'             => null,
            'otp_expires_at'  => null,
            'mobile_verified' => true,
        ]);

        // Auto-login after OTP verification — return Sanctum token
        $token  = $user->createToken('api-token')->plainTextToken;
        $wallet = Wallet::where('user_id', $user->id)
            ->selectRaw('COALESCE((SUM(debit) - SUM(credit)), 0) as balance')
            ->first();

        return response([
            'message'         => 'Mobile verified successfully',
            'mobile_verified' => true,
            'token'           => $token,
            'user'            => $user,
            'wallet'          => $wallet,
        ]);
    }
}
