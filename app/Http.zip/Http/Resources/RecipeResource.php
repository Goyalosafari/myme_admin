<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class RecipeResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id'      => $this->id,
            'food_id' => $this->food_id,
            'title'   => $this->title,
            'image'   => $this->image,
            'food'    => new FoodResource($this->whenLoaded('food')),
        ];
    }
}
